<?php
// This file can be place in a directory that is not in the Apache path for extra security.
$Host = "localhost:3306"; // the host. This is probably OK unless you are using a remote host
$User = "YourUserName"; // Change this to your MySql user name
$Password = "YourPassword"; // Change this to you MySql password
?>
