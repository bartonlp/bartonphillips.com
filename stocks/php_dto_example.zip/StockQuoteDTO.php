<?php
readonly class StockQuoteDTO {
  public function __construct(
    public string $symbol,
    public float $currentPrice,
    public float $high,
    public float $low,
    public float $previousClose,
    public float $change,
    public string $changePercent,
    public int $volume,
    public string $tradingDay
  ) {}
}
