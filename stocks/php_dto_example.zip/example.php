<?php
require_once "StockQuoteDTO.php";
require_once "StockOverviewDTO.php";
require_once "StockDataDTO.php";

$quote = new StockQuoteDTO(
  symbol: "AAPL",
  currentPrice: 189.45,
  high: 190.20,
  low: 188.00,
  previousClose: 188.50,
  change: 0.95,
  changePercent: "0.50%",
  volume: 12345678,
  tradingDay: "2025-05-29"
);

$overview = new StockOverviewDTO(
  qty: 100,
  purchasePrice: 180.00,
  name: "Apple Inc.",
  companyName: "Apple Inc.",
  dividend: "0.24",
  divYield: "0.5",
  moving50: "185.00",
  moving200: "175.00",
  divDate: "2025-06-10",
  divExDate: "2025-06-01",
  totalValue: 18945.00
);

$stockData = new StockDataDTO(quote: $quote, overview: $overview);

header('Content-Type: application/json');
echo json_encode($stockData, JSON_PRETTY_PRINT);
